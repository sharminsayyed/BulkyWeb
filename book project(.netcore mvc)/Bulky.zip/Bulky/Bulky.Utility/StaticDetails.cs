﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bulky.Utility
{
    // this cass consist of all constant for our webbsite 
    public static  class StaticDetails
    {
        // create roles for our application
        public const string Role_Admin = "Admin";
        public const string Role_Employee = "Employee";
        public const string Role_Company = "Company";
        public const string Role_Customer = "Customer";

    }
}
